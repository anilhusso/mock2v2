﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;

namespace MOCK2RESTCONSUMER
{
    public class Program
    {
        private static string Uri = "http://localhost:55534/api/values";
        public static async Task<IEnumerable<Coin>> GetList()
        {
            using (HttpClient client = new HttpClient())
            {
                string content = await client.GetStringAsync(Uri);
                IEnumerable<Coin> list = JsonConvert.DeserializeObject<IEnumerable<Coin>>(content);
                return list;
            }
        }

        public static async Task<Coin> GetById(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                string content = await client.GetStringAsync(Uri + id);
                Coin oneID = JsonConvert.DeserializeObject<Coin>(content);
                return oneID;
            }
        }
        public static async Task<Coin> Addcoin(Coin newcoin)
        {
            using (HttpClient client = new HttpClient())
            {

                var jsonString = JsonConvert.SerializeObject(newcoin); 

                StringContent content = new StringContent(jsonString, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(content);
                if (response.StatusCode == HttpStatusCode.Conflict)
                {
                    throw new Exception("coin eksisterer allerede. Prøv andet id");
                }
                response.EnsureSuccessStatusCode();
                string str = await response.Content.ReadAsStringAsync();
                Coin copyOfNewCoin = JsonConvert.DeserializeObject<Coin>(str); 
                return copyOfNewCoin; 
            }
        }
    }
}
