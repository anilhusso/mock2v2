﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MOCK2RESTSERVICE
{
    public class Coin
    {
        //properties
        public int ID { get; set; }
        public string Genstand { get; set; }
        public int Bud { get; set; }
        public string Navn { get; set; }

        //constructor
        public Coin(int id, string genstand, int bud, string navn)
        {
            ID = id;
            Genstand = genstand;
            Bud = bud;
            Navn = navn;
        }
        //tostring
        public override string ToString()
        {
            return $"{nameof(Navn)}: {Navn}, {nameof(Bud)}: {Bud}, {nameof(Genstand)}: {Genstand}, {nameof(ID)}:, {ID}";
        }
    }
}

