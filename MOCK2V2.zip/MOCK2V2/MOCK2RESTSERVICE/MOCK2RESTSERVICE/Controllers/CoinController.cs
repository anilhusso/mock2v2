﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
namespace MOCK2RESTSERVICE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoinController : ControllerBase
    {
        public static List<Coin> Clist = new List<Coin>()
        {
            new Coin(1, "GoldDK1640", 2500, "mike"),
            new Coin(2, "GoldNL1764", 5000, "Anbo"),
            new Coin(3, "GOLDFR1644", 35000, "Hammer"),
            new Coin(4, "GoldFR1644", 0, "Auction"),
            new Coin(5, "SilverGR333", 2500, "Mike"),
        };


        // GET: api/Coin
        [HttpGet]
        public List<Coin> GetALL()
        {
            return Clist;
        }

        // GET: api/Coin/5
        [HttpGet("{id}", Name = "Get")]
        public Coin GetoneCoin(int id)
        {
            return Clist.SingleOrDefault(coin => coin.ID == id);
        }

        // POST: api/Coin
        [HttpPost]
        public HttpResponseMessage Post([FromBody] Coin value)
        {
            if (Clist.Contains(value))
            {
                return new HttpResponseMessage(HttpStatusCode.NotModified);
            }
            else
            {
                Clist.Add(value);
                return new HttpResponseMessage(HttpStatusCode.Accepted);
            }
        }

        // PUT: api/Coin/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
